How to run the Student Record Management System (StudentSRMS) Project

1. Open google chrome

2. Run the script http://localhost/studentms (frontend)



Credential for admin panel :

Username: admin
Password: Test@123

Credential for Student / User panel :

Username: anujk3
Password: anuj123

Username: john12
Password: john123

 Or Register a new Student/User.